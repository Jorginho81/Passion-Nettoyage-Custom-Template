<?php $skip_min_height = false; ?><section class="u-align-center u-clearfix u-section-1" id="sec-4453">
  <div class="u-clearfix u-sheet u-valign-middle u-sheet-1"><!--products--><!--products_options_json--><!--{"type":"Recent","source":"","tags":"","count":""}--><!--/products_options_json-->
    <div class="u-expanded-width u-products u-repeater u-repeater-1"><?php global $npProductsData; $countItems = $npProductsData['countItems'];
            foreach ($npProductsData['products'] as $current_index => $product) {
            $templateOrder = $current_index % $countItems;
            ?><?php if ($templateOrder == 0) { ?><!--product_item-->
      <div class="u-align-center u-container-style u-products-item u-repeater-item u-white u-repeater-item-1">
        <div class="u-container-layout u-similar-container u-valign-top u-container-layout-1"><!--product_image-->
          <img alt="" class="u-expanded-width u-image u-image-contain u-image-default u-product-control u-image-1" src="<?php echo get_template_directory_uri(); ?>/images/d754debf.svg"><!--/product_image--><!--product_title-->
          <h4 class="u-product-control u-text u-text-1">
            <a class="u-product-title-link" href="#"><!--product_title_content-->Titre du produit 1<!--/product_title_content--></a>
          </h4><!--/product_title--><!--product_price-->
          <div class="u-product-control u-product-price u-product-price-1">
            <div class="u-price-wrapper u-spacing-10"><!--product_old_price-->
              <div class="u-hide-price u-old-price"><!--product_old_price_content-->$20.00<!--/product_old_price_content--></div><!--/product_old_price--><!--product_regular_price-->
              <div class="u-price u-text-palette-2-base" style="font-size: 1.25rem; font-weight: 700;"><!--product_regular_price_content-->$17.00<!--/product_regular_price_content--></div><!--/product_regular_price-->
            </div>
          </div><!--/product_price--><!--product_button--><!--options_json--><!--{"clickType":"add-to-cart","content":"Add to Cart"}--><!--/options_json-->
          <a href="#" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-product-control u-text-body-color u-btn-1 u-dialog-link u-payment-button" data-product-id=""><!--product_button_content-->Add to Cart<!--/product_button_content--></a><!--/product_button-->
        </div>
      </div><!--/product_item--><?php } ?><?php if ($templateOrder == 1) { ?><!--product_item-->
      <div class="u-align-center u-container-style u-products-item u-repeater-item u-white u-repeater-item-2">
        <div class="u-container-layout u-similar-container u-valign-top u-container-layout-2"><!--product_image-->
          <img alt="" class="u-expanded-width u-image u-image-contain u-image-default u-product-control u-image-2" src="<?php echo get_template_directory_uri(); ?>/images/53c4c417.svg"><!--/product_image--><!--product_title-->
          <h4 class="u-product-control u-text u-text-2">
            <a class="u-product-title-link" href="#"><!--product_title_content-->Titre du produit 2<!--/product_title_content--></a>
          </h4><!--/product_title--><!--product_price-->
          <div class="u-product-control u-product-price u-product-price-2">
            <div class="u-price-wrapper u-spacing-10"><!--product_old_price-->
              <div class="u-hide-price u-old-price"><!--product_old_price_content-->$300.00<!--/product_old_price_content--></div><!--/product_old_price--><!--product_regular_price-->
              <div class="u-price u-text-palette-2-base" style="font-size: 1.25rem; font-weight: 700;"><!--product_regular_price_content-->$245.00<!--/product_regular_price_content--></div><!--/product_regular_price-->
            </div>
          </div><!--/product_price--><!--product_button--><!--options_json--><!--{"clickType":"add-to-cart","content":"Add to Cart"}--><!--/options_json-->
          <a href="#" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-product-control u-text-body-color u-btn-2 u-dialog-link u-payment-button" data-product-id=""><!--product_button_content-->Add to Cart<!--/product_button_content--></a><!--/product_button-->
        </div>
      </div><!--/product_item--><?php } ?><?php if ($templateOrder == 2) { ?><!--product_item-->
      <div class="u-align-center u-container-style u-products-item u-repeater-item u-white u-repeater-item-3">
        <div class="u-container-layout u-similar-container u-valign-top u-container-layout-3"><!--product_image-->
          <img alt="" class="u-expanded-width u-image u-image-contain u-image-default u-product-control u-image-3" src="<?php echo get_template_directory_uri(); ?>/images/6537f30a.svg"><!--/product_image--><!--product_title-->
          <h4 class="u-product-control u-text u-text-3">
            <a class="u-product-title-link" href="#"><!--product_title_content-->Titre du produit 3<!--/product_title_content--></a>
          </h4><!--/product_title--><!--product_price-->
          <div class="u-product-control u-product-price u-product-price-3">
            <div class="u-price-wrapper u-spacing-10"><!--product_old_price-->
              <div class="u-hide-price u-old-price"><!--product_old_price_content-->$25.00<!--/product_old_price_content--></div><!--/product_old_price--><!--product_regular_price-->
              <div class="u-price u-text-palette-2-base" style="font-size: 1.25rem; font-weight: 700;"><!--product_regular_price_content-->$19.00<!--/product_regular_price_content--></div><!--/product_regular_price-->
            </div>
          </div><!--/product_price--><!--product_button--><!--options_json--><!--{"clickType":"add-to-cart","content":"Add to Cart"}--><!--/options_json-->
          <a href="#" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-product-control u-text-body-color u-btn-3 u-dialog-link u-payment-button" data-product-id=""><!--product_button_content-->Add to Cart<!--/product_button_content--></a><!--/product_button-->
        </div>
      </div><!--/product_item--><?php } ?><?php if ($templateOrder == 3) { ?><!--product_item-->
      <div class="u-align-center u-container-style u-products-item u-repeater-item u-white u-repeater-item-4">
        <div class="u-container-layout u-similar-container u-valign-top u-container-layout-4"><!--product_image-->
          <img alt="" class="u-expanded-width u-image u-image-contain u-image-default u-product-control u-image-4" src="<?php echo get_template_directory_uri(); ?>/images/776587db.svg"><!--/product_image--><!--product_title-->
          <h4 class="u-product-control u-text u-text-4">
            <a class="u-product-title-link" href="#"><!--product_title_content-->Titre du produit 4<!--/product_title_content--></a>
          </h4><!--/product_title--><!--product_price-->
          <div class="u-product-control u-product-price u-product-price-4">
            <div class="u-price-wrapper u-spacing-10"><!--product_old_price-->
              <div class="u-hide-price u-old-price"><!--product_old_price_content-->$25.00<!--/product_old_price_content--></div><!--/product_old_price--><!--product_regular_price-->
              <div class="u-price u-text-palette-2-base" style="font-size: 1.25rem; font-weight: 700;"><!--product_regular_price_content-->$20.00<!--/product_regular_price_content--></div><!--/product_regular_price-->
            </div>
          </div><!--/product_price--><!--product_button--><!--options_json--><!--{"clickType":"add-to-cart","content":"Add to Cart"}--><!--/options_json-->
          <a href="#" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-product-control u-text-body-color u-btn-4 u-dialog-link u-payment-button" data-product-id=""><!--product_button_content-->Add to Cart<!--/product_button_content--></a><!--/product_button-->
        </div>
      </div><!--/product_item--><?php } ?><?php if ($templateOrder == 4) { ?><!--product_item-->
      <div class="u-align-center u-container-style u-products-item u-repeater-item u-white u-repeater-item-5">
        <div class="u-container-layout u-similar-container u-valign-top u-container-layout-5"><!--product_image-->
          <img alt="" class="u-expanded-width u-image u-image-contain u-image-default u-product-control u-image-5" src="<?php echo get_template_directory_uri(); ?>/images/6f461f60.svg"><!--/product_image--><!--product_title-->
          <h4 class="u-product-control u-text u-text-5">
            <a class="u-product-title-link" href="#"><!--product_title_content-->Titre du produit 5<!--/product_title_content--></a>
          </h4><!--/product_title--><!--product_price-->
          <div class="u-product-control u-product-price u-product-price-5">
            <div class="u-price-wrapper u-spacing-10"><!--product_old_price-->
              <div class="u-hide-price u-old-price"><!--product_old_price_content-->$10.00<!--/product_old_price_content--></div><!--/product_old_price--><!--product_regular_price-->
              <div class="u-price u-text-palette-2-base" style="font-size: 1.25rem; font-weight: 700;"><!--product_regular_price_content-->$7.00<!--/product_regular_price_content--></div><!--/product_regular_price-->
            </div>
          </div><!--/product_price--><!--product_button--><!--options_json--><!--{"clickType":"add-to-cart","content":"Add to Cart"}--><!--/options_json-->
          <a href="#" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-product-control u-text-body-color u-btn-5 u-dialog-link u-payment-button" data-product-id=""><!--product_button_content-->Add to Cart<!--/product_button_content--></a><!--/product_button-->
        </div>
      </div><!--/product_item--><?php } ?><?php if ($templateOrder == 5) { ?><!--product_item-->
      <div class="u-align-center u-container-style u-products-item u-repeater-item u-white u-repeater-item-6">
        <div class="u-container-layout u-similar-container u-valign-top u-container-layout-6"><!--product_image-->
          <img alt="" class="u-expanded-width u-image u-image-contain u-image-default u-product-control u-image-6" src="<?php echo get_template_directory_uri(); ?>/images/caac4e54.svg"><!--/product_image--><!--product_title-->
          <h4 class="u-product-control u-text u-text-6">
            <a class="u-product-title-link" href="#"><!--product_title_content-->Titre du produit 6<!--/product_title_content--></a>
          </h4><!--/product_title--><!--product_price-->
          <div class="u-product-control u-product-price u-product-price-6">
            <div class="u-price-wrapper u-spacing-10"><!--product_old_price-->
              <div class="u-hide-price u-old-price"><!--product_old_price_content-->$175.00<!--/product_old_price_content--></div><!--/product_old_price--><!--product_regular_price-->
              <div class="u-price u-text-palette-2-base" style="font-size: 1.25rem; font-weight: 700;"><!--product_regular_price_content-->$150.00<!--/product_regular_price_content--></div><!--/product_regular_price-->
            </div>
          </div><!--/product_price--><!--product_button--><!--options_json--><!--{"clickType":"add-to-cart","content":"Add to Cart"}--><!--/options_json-->
          <a href="#" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-product-control u-text-body-color u-btn-6 u-dialog-link u-payment-button" data-product-id=""><!--product_button_content-->Add to Cart<!--/product_button_content--></a><!--/product_button-->
        </div>
      </div><!--/product_item--><?php } ?><?php } ?>
    </div><!--/products-->
  </div>
</section><?php if ($skip_min_height) { echo "<style> .u-section-1, .u-section-1 .u-sheet {min-height: auto;}</style>"; } ?>